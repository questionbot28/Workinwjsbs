require('dotenv').config();
const { Client, GatewayIntentBits, SlashCommandBuilder, Routes, REST } = require('discord.js');
const fs = require('fs');

const client = new Client({ intents: [GatewayIntentBits.Guilds, GatewayIntentBits.GuildMessages, GatewayIntentBits.MessageContent] });

client.once('ready', () => {
    console.log(`Logged in as ${client.user.tag}`);
});

client.on('interactionCreate', async interaction => {
    if (!interaction.isCommand()) return;

    const { commandName } = interaction;

    if (commandName === 'class11') {
        const questions = JSON.parse(fs.readFileSync('questions.json'));
        const question = questions.class11[Math.floor(Math.random() * questions.class11.length)];
        await interaction.reply(question);
    } else if (commandName === 'class12') {
        const questions = JSON.parse(fs.readFileSync('questions.json'));
        const question = questions.class12[Math.floor(Math.random() * questions.class12.length)];
        await interaction.reply(question);
    }
});

client.login(process.env.TOKEN);
