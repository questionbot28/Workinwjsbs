const fs = require('fs');

module.exports = {
    name: 'class11',
    description: 'Get a random Class 11 question',
    execute(interaction) {
        const questions = JSON.parse(fs.readFileSync('questions.json'));
        const question = questions.class11[Math.floor(Math.random() * questions.class11.length)];
        interaction.reply(question);
    }
};