const fs = require('fs');

module.exports = {
    name: 'class12',
    description: 'Get a random Class 12 question',
    execute(interaction) {
        const questions = JSON.parse(fs.readFileSync('questions.json'));
        const question = questions.class12[Math.floor(Math.random() * questions.class12.length)];
        interaction.reply(question);
    }
};